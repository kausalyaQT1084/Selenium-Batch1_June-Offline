package testNgFramework;
import java.util.Properties;

import javax.activation.DataHandler;

import javax.activation.DataSource;

import javax.activation.FileDataSource;



import org.openqa.selenium.WebDriver;

import org.testng.Assert;
import org.testng.IReporter;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.Listeners;

import org.testng.annotations.Test;




public class ReportGenerationLis extends BaseClass implements IReporter {
	 WebDriver driver;
	@Test
        
    public void testPDFReportOne(){
		driver.get("www.google.com");
    Assert.assertTrue(false);

    }
	 public void testPDFReportTwo(){
			driver.get("www.google.com");
	    Assert.assertTrue(false);

	    }
	}

