package testNgFramework;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


public class ParameterPassing {
	WebDriver driver;

    @Test(retryAnalyzer = RetryMechanismExample.class)
    @Parameters({"username", "password"})
    public void loginTest(String username, String password) {
    	String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();	    
  	options.addArguments("--remote-allow-origins=*");
  	DesiredCapabilities capabilities = new DesiredCapabilities();
  	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
  	options.merge(capabilities);
  	driver = new ChromeDriver(options);
        driver.get("https://magento.softwaretestingboard.com/");
        driver.findElement(By.id("email")).sendKeys(username);
        driver.findElement(By.id("pass")).sendKeys(password);
        driver.findElement(By.id("send2")).click();
        driver.quit();
    }

}
