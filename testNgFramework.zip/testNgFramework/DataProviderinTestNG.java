package testNgFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderinTestNG {

  // Declare the WebDriver instance
  WebDriver driver;

  // Define the URL to be tested
  String url = "https://magento.softwaretestingboard.com/";

  // This method will run before each test method
  @BeforeTest
  public void setUp() {
    // Set the system property for Chrome driver
	  String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
      ChromeOptions options = new ChromeOptions();	    
	options.addArguments("--remote-allow-origins=*");
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	options.merge(capabilities);
	driver = new ChromeDriver(options);
   // Navigate to the URL
    driver.get(url);

    // Maximize the browser window
    driver.manage().window().maximize();

  }

  // This method will run after each test method
  @AfterTest
  public void tearDown() {
    // Close the browser window
    driver.quit();
  }

  // This method will provide the test data for the search test
  @DataProvider(name = "searchData")
  public Object[][] searchData() {
    return new Object[][] {
      {"jacket"},
      {"shirt"},
      {"shoes"}
    };
  }

  // This method will test the search functionality of the web page using the data provider
  @Test(dataProvider = "searchData")
  public void searchTest(String searchTerm) {
    // Find the search box element by id
    By searchBox = By.id("search");

    // Clear the search box and enter the search term and submit
    driver.findElement(searchBox).clear();
    driver.findElement(searchBox).sendKeys(searchTerm);
    driver.findElement(searchBox).submit();

    // Print a message to indicate that the search is performed
    System.out.println("Search performed for " + searchTerm);
  }
}