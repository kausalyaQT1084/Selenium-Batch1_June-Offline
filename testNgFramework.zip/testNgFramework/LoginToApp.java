package testNgFramework;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginToApp extends BaseClass {
	 @Test(retryAnalyzer = RetryMechanismExample.class)
	    public void testLogin() {	        
	        // Find the email input and enter a valid email
	        driver.findElement(By.id("email")).sendKeys("rk2q1c2@gmail.com");
	        // Find the password input and enter a valid password
	        driver.findElement(By.id("pass")).sendKeys("Ilove@2010");
	        // Find the login button and click it
	        driver.findElement(By.id("send2")).click();
	        // Verify that the user is logged in by checking the welcome message
	        String welcomeMessage = driver.findElement(By.xpath("/html/body/div[1]/header/div[1]/div/ul/li[1]/span")).getText();
	        Assert.assertEquals(welcomeMessage, "Welcome, Kausalya Raghavan!");
	    }
	}