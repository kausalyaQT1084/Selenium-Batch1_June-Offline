package testNgFramework;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ParralelExcution extends BaseClass {



  WebDriver driver;

  @BeforeMethod
  public void setUp () {

  	String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();	    
  	options.addArguments("--remote-allow-origins=*");
  	DesiredCapabilities capabilities = new DesiredCapabilities();
  	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
  	options.merge(capabilities);
  	driver = new ChromeDriver(options);
	driver.get("https://magento.softwaretestingboard.com/");
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	driver.findElement(By.xpath("/html/body/div[1]/header/div[1]/div/ul/li[2]/a")).click();
  }

  @Test 
  public void loginTest () {
	  driver.findElement(By.id("email")).sendKeys("rk2q1c2@gmail.com");
      // Find the password input and enter a valid password
      driver.findElement(By.id("pass")).sendKeys("Ilove@2010");
      // Find the login button and click it
      driver.findElement(By.id("send2")).click();
  }
 
  @Test(threadPoolSize = 2)
	public void testWomenTab() {
		 Actions actions = new Actions(driver);
		 
	        actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"ui-id-5\"]/span[2]"))).perform();
	        actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"ui-id-17\"]/span[2]"))).perform();
	         driver.findElement(By.xpath("//*[@id=\"ui-id-19\"]/span")).click();
	       String gettilte= driver.findElement(By.xpath("//div[@class='page-title-wrapper']/h1")).getText();
	       System.out.println(gettilte);
  }
  @Test(threadPoolSize = 2)
  public void testMenTab() {
	 Actions actions = new Actions(driver);
	 
      actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"ui-id-4\"]/span[2]"))).perform();
      actions.moveToElement(driver.findElement(By.xpath("//*[@id=\"ui-id-9\"]/span[2]"))).perform();
       driver.findElement(By.xpath("//*[@id=\"ui-id-11\"]/span")).click();
     String gettilte= driver.findElement(By.xpath("//div[@class='page-title-wrapper']/h1")).getText();
     System.out.println(gettilte);
}
  @AfterMethod
  public void tearDown () {
    driver.quit ();
  }
}



