package testNgFramework;


// Import the required packages
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;

public class ReadFromExcel {

  // Declare the WebDriver instance
  WebDriver driver;

  // Define the URL to be tested
  String url = "https://magento.softwaretestingboard.com/";

  // Define the path of the excel file
  String excelPath = "C:\\Users\\kausa\\OneDrive\\Desktop\\QT Classes\\Selenium Batches\\Selenium Batch1\\ReadData.xlsx";

  // This method will run before each test method
  @BeforeTest
  public void setUp() {
    // Set the system property for Chrome driver
	  String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
      ChromeOptions options = new ChromeOptions();	    
	options.addArguments("--remote-allow-origins=*");
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	options.merge(capabilities);
	driver = new ChromeDriver(options);
 
    // Navigate to the URL
    driver.get(url);
 // Maximize the browser window
    driver.manage().window().maximize();
  }

  // This method will run after each test method
  @AfterTest
  public void tearDown() {
    // Close the browser window
    driver.quit();
  }

  // This method will read the data from the excel file and return it as a two-dimensional array of objects
  @DataProvider(name = "excelData")
  public Object[][] excelData() throws IOException {
    // Create a file input stream to read the excel file
    FileInputStream fis = new FileInputStream(excelPath);

    // Create a workbook instance to access the excel file
    Workbook workbook = new XSSFWorkbook(fis);

    // Get the first sheet from the workbook
    Sheet sheet = workbook.getSheetAt(0);

    // Get the number of rows and columns in the sheet
    int rowCount = sheet.getLastRowNum();
    int colCount = sheet.getRow(0).getLastCellNum();

    // Create a two-dimensional array of objects to store the data from the sheet
    Object[][] data = new Object[rowCount][colCount];

    // Loop through each row and column and get the cell value as a string and store it in the array
    for (int i = 1; i <= rowCount; i++) {
      Row row = sheet.getRow(i);
      for (int j = 0; j < colCount; j++) {
        data[i - 1][j] = row.getCell(j).getStringCellValue();
      }
    }

    // Close the file input stream and workbook instances
    fis.close();
    workbook.close();

    // Return the data array
    return data;
  }

  // This method will test the search functionality of the web page using the data from excel
  @Test(dataProvider = "excelData")
  public void searchTest(String searchTerm) {
    // Find the search box element by id
    By searchBox = By.id("search");

    // Clear the search box and enter the search term and submit
    driver.findElement(searchBox).clear();
    driver.findElement(searchBox).sendKeys(searchTerm);
    driver.findElement(searchBox).submit();

    // Print a message to indicate that the search is performed
    System.out.println("Search performed for " + searchTerm);
  }
}
