package testNgFramework;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class Google {

		private static WebDriver driver;
		@BeforeClass
		public void launchBrowser() throws InterruptedException
		{
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			String driverPath=System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver(options);	
			driver.manage().window().maximize();
			
		}
		public static WebDriver getDriver() {
	        return driver;
		}
		
		
		@Test
		public void googleTitleTest()
		{
			driver.get("http://www.google.com");
			String title=driver.getTitle();
			System.out.println(title);
		}
		 
		    
		@Test
		public void logoTest()
		{
		
			Boolean b=driver.findElement(By.xpath("//img[@class='lnXdpd']")).isDisplayed();
			System.out.println(b);
		}
		@AfterClass
		public void tearDown()

		{
			if (driver != null) {
	            driver.quit();
	        }

	}}



