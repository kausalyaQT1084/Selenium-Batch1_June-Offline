package colelction;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
public class HashSetExample {
public static void main(String[] args) {
	        // Create a Set of strings
	        //Set<String> fruits = new HashSet<>();
	        Set<String> fruitsa = new LinkedHashSet<String>();
	        SortedSet<String> fruits = new TreeSet<String>();
	        // Add elements to the Set
	        fruits.add("Apple");
	        fruits.add("apple");
	        fruits.add("Carrot");
	        fruits.add("Apple");
	        fruits.add("Banana");
	        fruits.add("Orange");
	        fruits.add("Mango");
	        fruitsa.add("Pineapple");
	        fruitsa.add("Pineapple");

	        // Print the elements of the Set
	        System.out.println("Set: " + fruits);
	        System.out.println("Set: " + fruitsa);
	        // Check if an element exists in the Set
	        boolean containsBanana = fruits.contains("Banana");
	        System.out.println("Contains Banana? " + containsBanana);

	        // Remove an element from the Set
	        boolean removed = fruits.remove("Orange");
	        System.out.println("Removed Orange? " + removed);

	        // Iterate over the Set using a for-each loop
	        System.out.println("Elements in the Set:");
	        for (String fruit : fruits) {
	            System.out.println(fruit);
	        }

	        // Get the size of the Set
	        int size = fruits.size();
	        System.out.println("Size of Set: " + size);

	        // Clear all elements from the Set
	        //fruits.clear();
	        //System.out.println("Cleared Set: " + fruits);

	        // Check if the Set is empty
	        boolean isEmpty = fruits.isEmpty();
	        System.out.println("Is Set empty? " + isEmpty);
	    }
	}
	




