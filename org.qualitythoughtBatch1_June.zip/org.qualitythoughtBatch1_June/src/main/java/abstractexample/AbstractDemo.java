package abstractexample;

public class AbstractDemo {

	public static void main(String [] args){
		Salary s = new Salary("Kausalya","Raghavan , TDD",3,3600.00);
		Employee e = new Salary("Amerit","Balikpapan , TSD",2,6600.00);
			
		  System.out.println("Call mailCheck using Salary reference --");
	      s.mailCheck();

	      System.out.println("\n Call mailCheck using Employee reference--");
	      e.mailCheck();
		
	}
}