package org.dailypracticeprograms;
import java.util.Scanner;

public class Pattern2 {

	public static void main(String[] args) {
System.out.println("Enter no of times pattern to be printed\n");
		
		Scanner no = new Scanner(System.in);
				
		int n=no.nextInt();
		
		
		for(int i=n;i>=1;i--)		
		{
			System.out.println();
			
			for(int j=i;j>=1;j--)
			{
			  System.out.print(j);
			}
		}

	}

}
