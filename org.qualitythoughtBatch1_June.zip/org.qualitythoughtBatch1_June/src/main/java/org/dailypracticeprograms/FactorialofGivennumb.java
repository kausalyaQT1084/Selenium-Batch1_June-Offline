package org.dailypracticeprograms;
import java.util.Scanner;
public class FactorialofGivennumb {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no ");
		int No =sc.nextInt();
		int fact=1;
		for(int i=1;i<=No;i++) 
			
			
			{				
				fact=fact*i;			
					
			}
			System.out.println("Factorial of given no is" +fact);
		}	
	}

