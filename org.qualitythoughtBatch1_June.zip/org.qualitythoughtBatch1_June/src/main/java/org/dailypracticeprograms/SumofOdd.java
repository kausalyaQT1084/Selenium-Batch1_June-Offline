package org.dailypracticeprograms;
import java.util.Scanner;
public class SumofOdd {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no up to summation to be performed");
		int No =sc.nextInt();
		int count=0;
		int j=0;
		for(int i=0;i<No;i++)
		{
			if(i%2==1)
			{
				count=count+i;
				System.out.println(count);
				//count of odd No
				j++;
				
		     }
			
		}
		System.out.println("count of odd nos is  "+j++);

	}

}
