package org.qualitythoughtBatch1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.util.List;

public class WebTableExample {
    public static void main(String[] args) {
        // Set the path to the chromedriver executable
    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
        // Maximize the browser window
        driver.manage().window().maximize();

     // Navigate to the web page with the table
        driver.get("https://www.browserstack.com");

        // Locate the table element
        WebElement table = driver.findElement(By.className("support-table"));

        // Get all rows in the table body
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        // Iterate over the rows
       
            // Iterate over the cells
            for (WebElement row : rows) {
                List<WebElement> cells = row.findElements(By.tagName("td"));
                for (WebElement cell : cells) {
                    System.out.print(cell.getText() + "\t");
                }
                System.out.println();
            }
    }
}
