package org.qualitythoughtBatch1;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.io.IOException;

public class MultipleScreenshot {
    public static void main(String[] args) {
        // Set the path to the chromedriver executable
    	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);

		driver.get("https://erail.in/");

        
        // Take multiple screenshots at different points
        takeScreenshot(driver, "screenshot1.png");
        
        // Perform actions on the webpage
        // ...
        
        takeScreenshot(driver, "screenshot2.png");
        
        // Perform more actions
        // ...
        
        takeScreenshot(driver, "screenshot3.png");
        
        }
    
    public static void takeScreenshot(WebDriver driver, String filename) {
        // Convert WebDriver instance to TakesScreenshot
        TakesScreenshot screenshot = (TakesScreenshot) driver;
        
        // Capture the screenshot as a file
        File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
        
        // Define the destination file path
        String destPath = "C:\\Users\\kausa\\OneDrive\\Desktop\\QT Classes\\Selenium Batches" + filename;
        
        try {
            // Copy the captured screenshot file to the destination path
            FileUtils.copyFile(srcFile, new File(destPath));
            System.out.println("Screenshot saved: " + destPath);
        } catch (IOException e) {
            System.out.println("Failed to save screenshot: " + e.getMessage());
        }
    }
}

