package org.qualitythoughtBatch1;

public class ObjectCreation {
	
	void cycle()
	{
		System.out.println("It contains 2 wheels ");
	}
	
	static public void car()
	{
		System.out.println("It contains 4 wheels ");
		int j=20;
		System.out.println(j);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ObjectCreation obj= new ObjectCreation();
	
		
		
			
		
		
}}


