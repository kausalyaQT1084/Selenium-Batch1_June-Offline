package org.qualitythoughtBatch1;

public class StringExercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		 String name = new String("Java Class");
		 String name1 = new String("java Class");
		 System.out.println(name.hashCode());
		 System.out.println(name);  // print Java String
		 System.out.println(name.contains("K")); 
		 System.out.println(name.replace("v", "k"));
		 System.out.println(name.hashCode());
		 System.out.println(name.equals(name1));
		 System.out.println(name.compareTo(name));
		 System.out.println(name.endsWith("J"));
		 
		char[] a= name.toCharArray();
		for (char k:a)
			System.out.println(k);
		
		 System.out.println(name.toCharArray());
		 System.out.println(name.substring(2));
		 System.out.println(name.toLowerCase());
		
		
        
}}


