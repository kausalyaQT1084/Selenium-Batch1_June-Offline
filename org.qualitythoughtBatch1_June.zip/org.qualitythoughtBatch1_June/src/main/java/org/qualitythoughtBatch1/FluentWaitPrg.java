package org.qualitythoughtBatch1;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
public class FluentWaitPrg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String driverPath = System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		System.out.println(driverPath);
		// Launch the browser
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		
		driver.get("http://www.google.com");
		
		//long startTime = System.currentTimeMillis();

	  
		Wait wait = new FluentWait(driver).withTimeout(Duration.ofSeconds(30)).pollingEvery(Duration.ofSeconds(30))
                .ignoring(NoSuchElementException.class);		
		try
		{
			
			/*WebElement foo = wait.until(new Function<WebDriver, WebElement>() 
					{
					  public WebElement apply(WebDriver driver) {
					  return driver.findElement(By.name("btnK"));
					}
					});
			*/
			
			WebElement element =  driver.findElement(By.name("q"));
			element.sendKeys("selenium");
			wait.until(ExpectedConditions.elementToBeClickable(element));
			driver.findElement(By.className("gNO89b")).click();
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
	}}
		          

	

