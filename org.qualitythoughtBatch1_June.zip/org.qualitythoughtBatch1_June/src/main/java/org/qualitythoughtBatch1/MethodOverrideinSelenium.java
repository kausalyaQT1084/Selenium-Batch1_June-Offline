package org.qualitythoughtBatch1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
public class MethodOverrideinSelenium  {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		//Load the url
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		DropDown d = new DropDown();
		
         driver.get("http://autopract.com/selenium/dropdown1/");
       // d.get("http://autopract.com/selenium/dropdown1/");
        driver.manage().window().maximize();
        WebElement dropD = driver.findElement(By.xpath("//select[@class='custom-select']"));
        Select e1 = new Select(dropD);
        //e1.selectByVisibleText("Table Tennis");
        e1.selectByIndex(3);

}}