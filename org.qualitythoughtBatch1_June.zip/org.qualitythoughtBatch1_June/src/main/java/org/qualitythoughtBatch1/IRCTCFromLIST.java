package org.qualitythoughtBatch1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;



public class IRCTCFromLIST {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);

		driver.get("https://erail.in/");

		driver.manage().window().maximize();
		try {
		WebElement fromStation = driver.findElement(By.id("txtStationFrom"));
		fromStation.clear();
		fromStation.sendKeys("MAS");
		Thread.sleep(500);
		fromStation.sendKeys(Keys.ENTER);
		}catch(Exception  e) {
			System.out.println("Program is Not correct");
		}
		try {
		WebElement toStation = driver.findElement(By.id("txtStationTo"));
		toStation.clear();
		toStation.sendKeys("CBE");
		Thread.sleep(500);
		toStation.sendKeys(Keys.ENTER);
		}catch(Exception e)
		{
			System.out.println("Ubale to find the element");
		}
		
		driver.findElement(By.id("chkSelectDateOnly")).click();
		
		Thread.sleep(1000);
		List<WebElement> trainNameEles = driver.findElements(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']//td[2]/a"));
		
		List<String> trainNames = new ArrayList<String>();
		System.out.println(trainNameEles.size());
		for (WebElement eachEle : trainNameEles) {
			String text = eachEle.getText();
			trainNames.add(text);
			System.out.println(text);
		}
		
		Set<String> trains = new HashSet<String>(trainNames);
		
		if(trainNames.size() == trains.size()) {
			System.out.println("No Duplicates");
		} else {
			System.out.println("Duplicates found");
		}
		
		
		
	}

}