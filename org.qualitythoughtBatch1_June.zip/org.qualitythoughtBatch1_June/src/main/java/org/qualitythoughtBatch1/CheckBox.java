package org.qualitythoughtBatch1;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
public class CheckBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		options.merge(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
	     driver.get("http://ramanasoft1-001-site1.ftempurl.com/Admin#");
	     driver.findElement(By.id("Email")).sendKeys("admin@yourstore.com");
	     driver.findElement(By.id("Password")).sendKeys("adminadmin");
	     driver.findElement(By.xpath("/html/body/div[7]/div[3]/div/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
	    driver.findElement(By.cssSelector("right fas fa-angle-left")).click();

	}

}
