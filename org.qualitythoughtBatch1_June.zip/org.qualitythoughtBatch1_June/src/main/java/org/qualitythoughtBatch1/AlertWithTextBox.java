package org.qualitythoughtBatch1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class AlertWithTextBox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
				System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--remote-allow-origins=*");
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				options.merge(capabilities);
				ChromeDriver driver = new ChromeDriver(options);
				driver.get("https://demo.automationtesting.in/Alerts.html");
		        // Maximize the browser window
		        driver.manage().window().maximize();
		        driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/ul/li[3]/a")).click();
		        driver.findElement(By.xpath("//div[@id='Textbox']/button")).click();

		        // Switch to the confirmation alert
		        Alert confirmationAlert = driver.switchTo().alert();
		        String alertText = confirmationAlert.getText();
		        System.out.println("Alert text: " + alertText);
		        Thread.sleep(3000);
		        confirmationAlert.sendKeys("Hi All!!");
		        confirmationAlert.accept();
		        
		     

}}
