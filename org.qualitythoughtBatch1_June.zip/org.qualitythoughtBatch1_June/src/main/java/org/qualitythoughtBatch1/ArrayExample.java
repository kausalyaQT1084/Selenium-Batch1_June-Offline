package org.qualitythoughtBatch1;

import java.util.Arrays;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//show to them without for loop, we will get only memory
		
		//create array
		int[] arr = {54,3,24,5,6};
		
		String arr1="Kausalya";
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.hashCode(arr));
	
		for(int i=0;i<arr.length;i++)
		System.out.println(arr[i]);
		
		 int intArr[] = { 10, 20, 15, 22, 35 };
		 int intArr1[] = { 10, 20, 22, 35  };
		 System.out.println("Integer Arrays on comparison: "
                 + Arrays.compare(intArr, intArr1));
		 System.out.println(Arrays.toString(Arrays.copyOf(intArr1,3 )));
		 System.out.println(Arrays.equals(intArr,intArr1));
	}

}
