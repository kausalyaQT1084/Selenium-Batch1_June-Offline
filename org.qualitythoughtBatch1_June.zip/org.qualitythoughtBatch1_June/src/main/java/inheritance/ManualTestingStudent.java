package inheritance;

public class ManualTestingStudent {

	public void studentDetail(){
		String s= "Kauslya";
		int id=10;
		System.out.println("Student name"+s);
		System.out.println("Student id"+id);
	}
}
